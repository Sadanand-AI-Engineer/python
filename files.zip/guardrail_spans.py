"""
Wraps GroundingVerifier.verify_claim() (src/grounding/verifier.py) as an
Arize `Guardrail` span. This is a drop-in decorator, not a rewrite -- the
verifier's own logic (citation resolution, lexical/numeric check, entailment)
is completely unchanged. This module only adds tracing around it.

Apply it by adding one decorator line to verifier.py:

    from observability.guardrail_spans import traced_guardrail

    class GroundingVerifier:
        @traced_guardrail
        def verify_claim(self, text, citations):
            ... existing body, unchanged ...

CRITICAL: claim text and quoted spans can contain real clinical text pulled
from a member's record. Every attribute below that could carry clinical
content is routed through redact() before being set. Do not add a new
span.set_attribute() call anywhere in this file without redacting first.
"""
from __future__ import annotations

import functools

from observability.tracing_init import tracer
from src.core.logging_conf import redact  # your existing PHI redaction function


def traced_guardrail(func):
    """Wrap a GroundingVerifier method as an Arize Guardrail span."""

    @functools.wraps(func)
    def wrapper(self, text, citations, *args, **kwargs):
        with tracer.start_as_current_span(
            "grounding.verify_claim",
            attributes={"openinference.span.kind": "GUARDRAIL"},
        ) as span:
            claim = func(self, text, citations, *args, **kwargs)

            # --- structural results: safe to log as-is, no clinical content ---
            span.set_attribute("guardrail.check1.citation_resolved", claim.citation_resolved)
            span.set_attribute("guardrail.check2.lexical_overlap", claim.lexical_overlap)
            span.set_attribute("guardrail.check2.numeric_verified", claim.numeric_tokens_verified)
            span.set_attribute("guardrail.check3.entailment_label", claim.entailment_label or "")
            span.set_attribute("guardrail.check3.entailment_confidence", claim.entailment_confidence)
            span.set_attribute("guardrail.status", claim.status.value)

            # --- anything that could be clinical text: redact first ---
            span.set_attribute(
                "guardrail.claim_text_redacted", redact(claim.text or "")
            )
            span.set_attribute(
                "guardrail.failure_reasons_redacted",
                redact("; ".join(claim.failure_reasons)),
            )
            if claim.unverified_numbers:
                # numbers themselves are not PHI, safe to log directly
                span.set_attribute(
                    "guardrail.unverified_numbers", ",".join(claim.unverified_numbers)
                )

            return claim

    return wrapper


def traced_evidence_verification(func):
    """
    Same pattern for GroundingVerifier.verify_evidence() -- the batch path
    that stamps EvidenceItem.grounding. One span per evidence item, so a
    single Arize trace shows exactly which findings passed/failed and why.
    """

    @functools.wraps(func)
    def wrapper(self, items, *args, **kwargs):
        with tracer.start_as_current_span(
            "grounding.verify_evidence_batch",
            attributes={"openinference.span.kind": "GUARDRAIL", "guardrail.batch_size": len(items)},
        ) as span:
            result = func(self, items, *args, **kwargs)
            verified = sum(1 for i in result if i.usable)
            span.set_attribute("guardrail.verified_count", verified)
            span.set_attribute("guardrail.quarantined_count", len(result) - verified)
            span.set_attribute(
                "guardrail.quarantine_ratio",
                (len(result) - verified) / len(result) if result else 0.0,
            )
            return result

    return wrapper
