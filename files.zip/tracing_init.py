"""
Arize AX tracing bootstrap for UW AI Assist.

Call init_tracing() exactly once, at process startup, BEFORE anything imports
src.agents.orchestrator or src.llm.gateway. Correct call sites:
  - scripts/run_case.py            -> top of main()
  - src/api/main.py                -> FastAPI startup event
  - the AKS pod entrypoint          -> before uvicorn.run(...)

Keys: pull ARIZE_SPACE_ID / ARIZE_API_KEY from Key Vault (or your secret
manager), never from a committed .env. Placeholders below.
"""
from __future__ import annotations

import os

from arize.otel import register
from openinference.instrumentation.langchain import LangChainInstrumentor
from openinference.instrumentation.openai import OpenAIInstrumentor

# --------------------------------------------------------------------------- placeholders
ARIZE_SPACE_ID = os.environ.get("ARIZE_SPACE_ID", "REPLACE_WITH_SPACE_ID")
ARIZE_API_KEY = os.environ.get("ARIZE_API_KEY", "REPLACE_WITH_API_KEY")
ARIZE_PROJECT_NAME = os.environ.get("ARIZE_PROJECT_NAME", "uw-ai-assist-dev")
# ---------------------------------------------------------------------------


def init_tracing():
    """
    Registers a TracerProvider that ships spans to Arize AX, then instruments:
      - LangChain/LangGraph  -> covers src/agents/orchestrator.py's graph shape
      - OpenAI SDK           -> covers every call inside src/llm/gateway.py's
                                 GatewayLLM._client_for(), with NO code change
                                 needed inside gateway.py itself.

    Returns the tracer_provider so callers can pass it into manual spans
    (see observability/guardrail_spans.py).
    """
    tracer_provider = register(
        space_id=ARIZE_SPACE_ID,
        api_key=ARIZE_API_KEY,
        project_name=ARIZE_PROJECT_NAME,
    )
    LangChainInstrumentor().instrument(tracer_provider=tracer_provider)
    OpenAIInstrumentor().instrument(tracer_provider=tracer_provider)
    return tracer_provider


# module-level tracer for manual spans elsewhere in this package
from opentelemetry import trace  # noqa: E402

tracer = trace.get_tracer("uw-ai-assist")
