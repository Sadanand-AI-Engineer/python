# Arize AX — Full Implementation Guide for UW AI Assist
### Code included. Keys as placeholders. Covers Foundry track and AKS track.

> **What I actually reviewed to write this:** the Arize AX docs pages on tracing
> concepts, OpenTelemetry/`arize-otel` setup, LangChain/LangGraph instrumentation,
> the Guardrail span kind, online and offline evaluators, Datasets & Experiments,
> Signal, and the Security & Settings pages (Private Connect, SSO/RBAC, Data
> Regions). Not every single sub-page under `/docs/ax` — that's several hundred
> pages — but every page that this project's actual implementation touches.
>
> **On the attached PDF:** it's a transcript of your own prior chat notes about
> Arize's docs, not a POC code file. There's no separate code artifact in it to
> review — so everything below is built directly against your real `uw-ai-assist`
> codebase (`gateway.py`, `orchestrator.py`, `verifier.py`, `engine.py`,
> `seed_synthetic.py`), which is the thing that actually needs to integrate.

---

## 0. The five things Arize AX gives you, and exactly which file changes for each

| Capability | What it does | Where it plugs into your code |
|---|---|---|
| **Tracing** | every agent/LLM/retrieval call becomes a span, grouped into a trace | `observability/tracing_init.py` — called once at startup |
| **Guardrail spans** | your existing 3-check grounding verifier, made visible per-check | `observability/guardrail_spans.py` — decorates `verifier.py` |
| **Code Evaluators** | deterministic, LLM-free regression checks against live traces | `evaluation/code_evaluator_rule_drift.py` |
| **Datasets + Experiments** | prove a prompt/model change is actually better before shipping | `evaluation/build_golden_dataset.py` + `run_experiment.py` |
| **Signal** | auto-clusters recurring failures, no manual alert rules | UI-only, Section 6 |

All five code files are provided alongside this guide. Every `API_KEY` / `SPACE_ID` in them is a placeholder — pull the real values from Key Vault at runtime, never commit them.

---

## 1. Install

```bash
pip install "arize[otel]" \
  openinference-instrumentation-langchain \
  openinference-instrumentation-openai \
  arize-phoenix-evals \
  pandas
```

- `arize[otel]` — the SDK plus the OTel wrapper (`arize.otel.register`)
- `openinference-instrumentation-langchain` — covers **LangGraph too**; your `orchestrator.py`'s LangGraph-shaped state machine needs no separate package
- `openinference-instrumentation-openai` — patches the `openai` SDK client at the library level, so every call inside `GatewayLLM._client_for()` gets traced with **zero changes to `gateway.py`**

---

## 2. Get your keys (placeholders shown — replace with real values from Key Vault)

- Arize app → bottom-left gear icon → **Space Settings** → copy **Space ID** and **API Key**
- Store as `ARIZE_SPACE_ID`, `ARIZE_API_KEY` in `kv-uwassist-<env>`, same pattern as every other secret in this project
- One Arize **project** per environment: `ARIZE_PROJECT_NAME = uw-ai-assist-dev / -qa / -prod`

```python
# NEVER commit real values. This is the .env shape only.
ARIZE_SPACE_ID=REPLACE_WITH_SPACE_ID
ARIZE_API_KEY=REPLACE_WITH_API_KEY
ARIZE_PROJECT_NAME=uw-ai-assist-dev
```

---

## 3. Wire tracing in (one call, one file)

`observability/tracing_init.py` (provided) does this:

```python
from arize.otel import register
from openinference.instrumentation.langchain import LangChainInstrumentor
from openinference.instrumentation.openai import OpenAIInstrumentor

def init_tracing():
    tracer_provider = register(
        space_id=ARIZE_SPACE_ID, api_key=ARIZE_API_KEY, project_name=ARIZE_PROJECT_NAME,
    )
    LangChainInstrumentor().instrument(tracer_provider=tracer_provider)
    OpenAIInstrumentor().instrument(tracer_provider=tracer_provider)
    return tracer_provider
```

**Call it once, before anything else imports your agents:**
- `scripts/run_case.py` → top of `main()`
- `src/api/main.py` → FastAPI startup event
- AKS pod entrypoint → before `uvicorn.run(...)`

That's it for basic tracing — every `IntentAgent`/`VectorAgent`/`SQLAgent`/`ChatbotAgent`/`SummaryAgent` call, every `HybridRetriever.retrieve()`, every `GatewayLLM.chat()` call now produces a span automatically.

---

## 4. Name spans to match your actual agents (2-line change, one file)

Auto-instrumentation names spans generically (`ChatCompletion`, `LangGraph`). To get your real agent names in the trace tree, add this to `src/agents/base.py`'s `Agent.__call__()`:

```python
from observability.tracing_init import tracer

def __call__(self, state: AgentState) -> AgentState:
    with tracer.start_as_current_span(self.name, attributes={"openinference.span.kind": "CHAIN"}):
        state = self.run(state)
    ...
```

One shared base class → every agent inherits it. Now your traces show `IntentAgent`, `VectorAgent`, `SQLAgent`, etc. as distinct named spans instead of one opaque `LangGraph` blob.

---

## 5. Guardrail spans — the 3-check verifier, made visible

`observability/guardrail_spans.py` (provided) is a decorator, not a rewrite. Apply it with one import + one line in `src/grounding/verifier.py`:

```python
from observability.guardrail_spans import traced_guardrail

class GroundingVerifier:
    @traced_guardrail
    def verify_claim(self, text, citations):
        ...  # existing body, completely unchanged
```

This produces a `Guardrail`-kind span per claim, with `guardrail.check1.citation_resolved`, `guardrail.check2.lexical_overlap`, `guardrail.check3.entailment_label`, and `guardrail.status` as filterable attributes — you can now filter directly in Arize's trace view on `guardrail.status = QUARANTINED` without opening your own logs.

**PHI redaction is built into the decorator, not optional.** Every attribute that could carry clinical text (`claim.text`, `failure_reasons`) is routed through your existing `src/core/logging_conf.redact()` before being set. This is the single most important line in this whole implementation — spans leave your process boundary, and unredacted PHI in a span attribute is a real incident, not a style nitpick.

---

## 6. Signal — skip hand-built alert rules

- Arize project → **Signal & Agents** tab → **Enable Signal**
- Signal reads your traces (including the redacted guardrail attributes from Section 5) and clusters recurring quarantine patterns into ranked issues with example traces attached automatically
- This answers "why is quarantine ratio spiking," not just "that it spiked" — a level of insight your App Insights alert rule alone doesn't give you

---

## 7. Evaluators — three kinds, used for three different things

### 7a. Online LLM-as-judge (for narrative quality — genuinely subjective content)
- Arize UI → **Evaluate → Online Evals → New Task → LLM-as-a-Judge**
- Use the built-in **Faithfulness** template against `SummaryAgent._narrate()` output — runs *alongside* your own entailment check as a second independent signal, not a replacement
- **Judge model must be a different deployment than the one being evaluated** — same rule you already enforce for `MODEL_VERIFIER ≠ MODEL_EXTRACTION`. Configure via **Settings → AI Provider Integrations**.

### 7b. Online Code Evaluator (for anything with a deterministic right answer, scored at low cost)
- Arize UI → **Evaluate → Online Evals → New Task → Code Evaluator**
- Good fit for structural checks (e.g., "does every INCONSISTENT determination carry a citation") that don't need your full `RuleEngine` imported

### 7c. Offline Code Evaluator — the actual rule-engine regression check (the "brilliant method")
This is `evaluation/code_evaluator_rule_drift.py` (provided). **Why offline, not the UI's online Code Evaluator:** the UI sandbox can only run against span data you pass in — it cannot `import src.rules.engine.RuleEngine` from your live codebase. This script does exactly that:

```python
from src.rules.engine import RuleEngine
from arize.pandas.logger import Client as ArizeClient

def replay_and_score(row, engine):
    status, _ = engine._decide(...)          # re-run the ACTUAL deterministic logic
    matches = status.value == row["attributes.rule_engine.traced_verification"]
    return {
        "context.span_id": row["context.span_id"],
        "eval.RuleEngineDrift.label": "MATCH" if matches else "DRIFT",
        "eval.RuleEngineDrift.score": 1.0 if matches else 0.0,
        "eval.RuleEngineDrift.explanation": f"...",
    }

client.spans.update_evaluations(space_id=SPACE_ID, project_name=PROJECT_NAME, dataframe=evals_df)
```

**What this catches that nothing else does:** if `underwriting_rules.yaml` gets edited and hot-reloaded without a version bump, or a code change silently alters `_decide()`'s branching, this flags `DRIFT` on live production traces — a continuous, zero-LLM-cost regression detector for the part of your system that's supposed to never change behavior silently. Run it as a scheduled job (cron / AKS CronJob) every 30 minutes.

---

## 8. Datasets + Experiments — your golden test cases, made reusable

You already built exactly the right dataset without knowing it: `scripts/seed_synthetic.py`'s nine designed cases (family-history trap, out-of-scope-cancer trap, duplicate-hospitalization trap).

`evaluation/build_golden_dataset.py` (provided) uploads them as an Arize Dataset — reusing `seed_synthetic.py`'s own fixtures so the two never drift apart:

```python
import scripts.seed_synthetic as seed
from arize import ArizeClient

df = build_examples()   # one row per question, expected_verification attached
client.datasets.create(space=SPACE, name="uw-ai-assist-golden-cases-v1", dataframe=df)
```

`evaluation/run_experiment.py` (provided) then runs **two pipeline versions against the same dataset**, scored by the same evaluator:

```python
experiment, experiment_df = client.experiments.run(
    name=f"uw-ai-assist-{version_label}",
    dataset="uw-ai-assist-golden-cases-v1",
    task=make_task(version_label),
    evaluators=[rule_match_evaluator],
)
```

Run it as `--version v1_current` then `--version v2_candidate`, compare pass rates side by side in the Arize UI. **This is the literal implementation of the evaluation-gate / A-B-testing requirement already described at the architecture level in your AKS deck — this script is what sits behind that requirement, not a separate manual process.**

---

## 9. Security — non-negotiable, not hardening you add later

- **Arize Private Connect (Azure Private Link)** — Arize → **Settings → Security → Arize Private Connect**. **Not self-service** — requires contacting `support@arize.com` to provision. Start this conversation now, in parallel with everything else, since it's the longest lead-time item and gates whether trace data can leave your VNet at all.
- **SSO & RBAC** — Arize → **Settings → SSO & RBAC** — wire to the same Entra ID tenant as everything else in this project. No separate Arize-only accounts.
- **Data Regions & Whitelisting** — Arize → **Settings → Data Regions & Whitelisting** — confirm the data region matches your PHI residency requirement before sending a single real trace.
- **Cost tracking** — automatic once `OpenAIInstrumentor` is active; token counts and cost appear on `LLM` spans without extra code, sourced from the same `prompt_tokens`/`completion_tokens` your `LLMResponse` dataclass already captures.

---

## 10. Where this sits in each architecture track

**Foundry track:** Arize runs *alongside* Foundry's own Tracing/Evaluation tabs (already wired to App Insights per the earlier Foundry doc's Section I), not instead of them. Arize adds per-check guardrail visibility (Section 5), rule-engine drift detection (Section 7c), and Signal clustering (Section 6) that Foundry's native tooling doesn't provide. Recommend running both for one QA cycle before deciding whether Arize supplements or replaces Foundry evaluation.

**AKS track:** `init_tracing()` (Section 3) is called once at pod startup, identically to how the App Insights connection was described in the AKS deck's Observability card. OTel supports multiple simultaneous exporters, so Arize is **additive** — Container Insights/App Insights keep working unchanged.

---

## 11. AIRB / Enterprise Safety Review — what a reviewer checks, and what answers it

This is the section to walk a reviewer through directly. Each row is a real AIRB-style question with the concrete Arize+code answer, not a hand-wave.

| Reviewer asks | Concrete answer |
|---|---|
| "How do you know the model isn't hallucinating in production?" | 3-check grounding verifier, now visible per-check as Guardrail spans (Section 5); quarantine ratio filterable directly in the trace UI |
| "How do you know a rule change didn't silently break underwriting logic?" | Offline Code Evaluator replays the actual `RuleEngine` against every live trace and flags `DRIFT` (Section 7c) — the deterministic core is checked continuously, not just at test-time |
| "How do you prove a prompt/model change is actually better before it ships?" | Experiments run both versions against the same 9-case golden dataset with the same evaluator (Section 8) — a side-by-side score, not an opinion |
| "What happens to PHI in your observability pipeline?" | Every guardrail span attribute is redacted through the existing `redact()` function before it's set (Section 5) — enforced in code, not policy alone |
| "Does trace data leave our network?" | Only via Arize Private Connect / Azure Private Link once provisioned (Section 9) — flagged as the longest-lead-time item to start immediately |
| "Who can access this telemetry data?" | SSO & RBAC wired to the same Entra tenant as the rest of the system (Section 9) — no separate identity silo |
| "How do you know recurring failure patterns get caught, not just individual incidents?" | Signal clusters recurring quarantine patterns automatically (Section 6) — pattern-level, not per-trace |
| "Can the model ever render an underwriting decision?" | Unaffected by this integration — GD-009 enforcement stays in `guardrails/policy.py`, application-level, same as always. Arize observes it; it does not replace it. |
| "Is this a new vendor risk?" | No — reference org (`UHCMR-Sales-AI-Co`, `compliance-advisor-api`) already runs Arize AX against a LangGraph agent in this same enterprise; this is an extension of an approved tool, not a new one |

---

## 12. Files provided with this guide

```
observability/
  tracing_init.py            -- Section 3
  guardrail_spans.py         -- Section 5
evaluation/
  code_evaluator_rule_drift.py   -- Section 7c
  build_golden_dataset.py        -- Section 8
  run_experiment.py              -- Section 8
```

Every `SPACE_ID` / `API_KEY` in these files is a placeholder constant at the top of the file — replace with Key Vault references before any real run, never with a literal value in the file itself.
