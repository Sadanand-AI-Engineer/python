"""
Turns scripts/seed_synthetic.py's nine hand-designed cases (family-history
trap, out-of-scope cancer trap, duplicate-hospitalization trap, etc.) into
an Arize Dataset -- your golden regression set, reused for every experiment
in run_experiment.py.

You already built this test data for pytest (tests/test_end_to_end.py).
This script does not duplicate that data -- it imports the same seed module
so the two stay in sync by construction.
"""
from __future__ import annotations

import os

import pandas as pd
from arize import ArizeClient

import scripts.seed_synthetic as seed  # reuse the existing fixtures, don't fork them

# --------------------------------------------------------------------------- placeholders
API_KEY = os.environ.get("ARIZE_API_KEY", "REPLACE_WITH_API_KEY")
SPACE = os.environ.get("ARIZE_SPACE_ID", "REPLACE_WITH_SPACE_ID")
DATASET_NAME = "uw-ai-assist-golden-cases-v1"
# ---------------------------------------------------------------------------


def build_examples() -> pd.DataFrame:
    """
    One row per application question in the seed data, each carrying the
    expected determination as documented in seed_synthetic.py's own comment
    block (Q5A -> INCONSISTENT, Q6D -> CONSISTENT, Q6E -> CONSISTENT via
    scope_filter, etc.) -- copied here explicitly so the dataset is
    self-describing in the Arize UI without needing to re-read the seed file.
    """
    expected = {
        "5A": "INCONSISTENT",   # CKD Stage 4 documented, answered No
        "6A": "INCONSISTENT",   # 3 inpatient stays in 2 years, answered No
        "6B": "CONSISTENT",     # no home health, answered No
        "6C": "INCONSISTENT",   # pending lung biopsy, answered No (advice rule)
        "6D": "CONSISTENT",     # family-history ESRD only -- must NOT flag
        "6E": "CONSISTENT",     # breast cancer, out of scope for leukemia/lymphoma/myeloma
        "7A": "CONSISTENT",     # breast cancer treatment in-window, answered Yes
        "7B": "CONSISTENT",     # COPD outside 2y window, answered No
        "7C": "INSUFFICIENT_EVIDENCE",  # cardiac stent only (inferred), answered No
    }

    rows = []
    for answer in seed.APPLICATION_ANSWERS:
        qid = answer["id"]
        rows.append({
            "input": f"Q{qid}: {answer['question']} | member_answer={answer['answer']}",
            "question_id": qid,
            "member_answer": answer["answer"],
            "member_id": seed.MEMBER_ID,
            "reference_date": seed.TODAY.isoformat(),
            "expected_verification": expected[qid],
        })
    return pd.DataFrame(rows)


def main() -> None:
    client = ArizeClient(api_key=API_KEY)
    df = build_examples()
    dataset = client.datasets.create(
        space=SPACE,
        name=DATASET_NAME,
        dataframe=df,
    )
    print(f"Created dataset '{DATASET_NAME}' with {len(df)} rows: {dataset}")
    print("Includes the two hardest traps on purpose:")
    print("  Q6D -- family-history ESRD must not be attributed to the applicant")
    print("  Q6E -- breast cancer must not falsely flag a leukemia/lymphoma/myeloma-only question")


if __name__ == "__main__":
    main()
