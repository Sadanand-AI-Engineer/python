"""
Runs the SAME golden dataset (build_golden_dataset.py) through two versions
of the pipeline -- e.g. current narrative prompt vs. a candidate change, or
gpt-4o vs gpt-5 once gateway access allows it -- and scores both with the
SAME evaluator, so the comparison is apples-to-apples.

This is the concrete implementation of the evaluation-gate / A-B-testing
requirement already described at the architecture level in the AKS deck --
this script is what actually sits behind that requirement.

Usage:
    python run_experiment.py --version v1_current_prompt
    python run_experiment.py --version v2_candidate_prompt
Then compare the two experiment runs side by side in the Arize UI.
"""
from __future__ import annotations

import argparse
import os
from datetime import date

from arize import ArizeClient

from src.rules.engine import RuleEngine

# --------------------------------------------------------------------------- placeholders
API_KEY = os.environ.get("ARIZE_API_KEY", "REPLACE_WITH_API_KEY")
SPACE = os.environ.get("ARIZE_SPACE_ID", "REPLACE_WITH_SPACE_ID")
DATASET_NAME = "uw-ai-assist-golden-cases-v1"
# ---------------------------------------------------------------------------


def make_task(version_label: str):
    """
    The task IS your pipeline. Swap this function body between experiment
    runs to compare versions -- e.g. point at MODEL_QA=gpt-4o vs gpt-5,
    or a candidate narrative prompt -- everything else in this script
    stays identical, which is what makes the comparison valid.
    """

    def task(example: dict) -> dict:
        engine = RuleEngine(reference_date=date.fromisoformat(example["reference_date"]))
        # In a real run this calls your full orchestrator; shown here as the
        # deterministic core only, since that's what must NEVER drift between
        # versions -- the prompt/model changes should affect narrative
        # quality, not the underlying determination.
        checks = engine.check_application_answers(
            [{"id": example["question_id"], "answer": example["member_answer"]}],
            evidence=[],  # populate from your real retrieval step in production use
        )
        actual = checks[0].verification.value if checks else "NOT_APPLICABLE"
        return {"output": actual, "pipeline_version": version_label}

    return task


def rule_match_evaluator(output: dict, example: dict) -> dict:
    """Code evaluator: does the pipeline's output match the documented expectation?"""
    matches = output["output"] == example["expected_verification"]
    return {
        "label": "MATCH" if matches else "MISMATCH",
        "score": 1.0 if matches else 0.0,
        "explanation": f"expected={example['expected_verification']} actual={output['output']}",
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--version", required=True, help="label for this experiment run")
    args = parser.parse_args()

    client = ArizeClient(api_key=API_KEY)

    experiment, experiment_df = client.experiments.run(
        name=f"uw-ai-assist-{args.version}",
        dataset=DATASET_NAME,
        space=SPACE,
        task=make_task(args.version),
        evaluators=[rule_match_evaluator],
    )

    pass_rate = experiment_df["eval.rule_match_evaluator.score"].mean()
    print(f"Experiment '{args.version}': {pass_rate:.0%} match rate across "
          f"{len(experiment_df)} golden cases")
    print("Open the Experiments tab in Arize AX and compare this run "
          "against the previous version's run before promoting.")


if __name__ == "__main__":
    main()
