"""
The "brilliant method" piece: a Code Evaluator that re-runs your ACTUAL
deterministic RuleEngine against traced production inputs, and flags DRIFT
if the live traced determination doesn't match what the rule engine would
produce right now. Zero LLM cost. Catches silent rulebook/code regressions
that no LLM-judge evaluator is qualified to catch (an LLM judging whether
"2024-08-24 >= cutoff" was computed correctly is a worse idea than the
arithmetic itself).

Run this as a scheduled job (cron / Azure Function / AKS CronJob), e.g. every
30 minutes, against the last window of traces. This is the OFFLINE evaluator
path (client.spans.update_evaluations), not an online Task, because it needs
to import and call your actual RuleEngine class, which the Arize UI's
built-in Code Evaluator sandbox cannot do -- it only runs against span data
passed in, not your live codebase.
"""
from __future__ import annotations

import os
from datetime import datetime, timedelta, timezone

import pandas as pd
from arize.exporter import ArizeExportClient
from arize.pandas.logger import Client as ArizeClient
from arize.utils.types import Environments

from src.rules.engine import RuleEngine
from src.rules.loader import load_rulebook

# --------------------------------------------------------------------------- placeholders
SPACE_ID = os.environ.get("ARIZE_SPACE_ID", "REPLACE_WITH_SPACE_ID")
API_KEY = os.environ.get("ARIZE_API_KEY", "REPLACE_WITH_API_KEY")
PROJECT_NAME = os.environ.get("ARIZE_PROJECT_NAME", "uw-ai-assist-prod")
# ---------------------------------------------------------------------------


def export_recent_rule_spans(hours: int = 1) -> pd.DataFrame:
    """Pull the last N hours of `determine` spans (see engine.py's DecisionTraceEntry)."""
    export_client = ArizeExportClient()
    end = datetime.now(timezone.utc)
    start = end - timedelta(hours=hours)
    df = export_client.export_model_to_df(
        space_id=SPACE_ID,
        model_id=PROJECT_NAME,
        environment=Environments.TRACING,
        start_time=start,
        end_time=end,
    )
    # keep only the spans you tagged with the rule-engine attributes
    return df[df["attributes.rule_engine.question_id"].notna()].copy()


def replay_and_score(row: pd.Series, engine: RuleEngine) -> dict:
    """
    Re-run the SAME deterministic logic against the traced inputs and compare
    to what was actually returned to the underwriter at the time.
    """
    try:
        status, _reasons = engine._decide(
            member_answer=row["attributes.rule_engine.member_answer"],
            supporting=row["attributes.rule_engine.supporting_count"] > 0 and [object()] or [],
            inferred_only=row["attributes.rule_engine.inferred_count"] > 0 and [object()] or [],
            out_of_lookback=row["attributes.rule_engine.out_of_lookback_count"] > 0 and [object()] or [],
            special_satisfied=row.get("attributes.rule_engine.special_satisfied"),
        )
        matches = status.value == row["attributes.rule_engine.traced_verification"]
        label = "MATCH" if matches else "DRIFT"
        score = 1.0 if matches else 0.0
        explanation = (
            f"replayed={status.value} traced={row['attributes.rule_engine.traced_verification']}"
        )
    except Exception as exc:  # noqa: BLE001 -- a replay failure IS a drift signal
        label, score = "REPLAY_ERROR", 0.0
        explanation = f"{type(exc).__name__}: {exc}"

    return {
        "context.span_id": row["context.span_id"],
        "eval.RuleEngineDrift.label": label,
        "eval.RuleEngineDrift.score": score,
        "eval.RuleEngineDrift.explanation": explanation,
    }


def main() -> None:
    book = load_rulebook()
    print(f"Replaying against ruleset {book.version} ({book.status})")

    spans_df = export_recent_rule_spans(hours=1)
    if spans_df.empty:
        print("No rule-engine spans in the last window. Nothing to evaluate.")
        return

    # reference_date must match what the engine used at trace time -- pull it
    # from the traced attribute rather than using today's date, or every
    # historical trace will falsely drift on lookback-boundary cases.
    results = []
    for _, row in spans_df.iterrows():
        ref_date = row.get("attributes.rule_engine.reference_date")
        engine = RuleEngine(reference_date=ref_date)
        results.append(replay_and_score(row, engine))

    evals_df = pd.DataFrame(results)
    drift_count = (evals_df["eval.RuleEngineDrift.label"] != "MATCH").sum()
    print(f"{len(evals_df)} spans replayed, {drift_count} DRIFT/ERROR.")

    client = ArizeClient(api_key=API_KEY)
    client.spans.update_evaluations(
        space_id=SPACE_ID,
        project_name=PROJECT_NAME,
        dataframe=evals_df,
    )
    print("Logged back to Arize AX -- filter on eval.RuleEngineDrift.label = 'DRIFT' to review.")


if __name__ == "__main__":
    main()
