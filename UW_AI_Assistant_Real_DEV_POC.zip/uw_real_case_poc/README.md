# UW AI Assistant Real DEV Case POC

Read-only vertical slice:
Salesforce DEV identifiers -> enterprise APIs already validated in Insomnia -> optional member PDF -> Azure Document Intelligence -> approved GPT gateway -> evidence summary.

Azure AI Search is intentionally excluded from v1 because current Search operations are returning 403.

## Setup (PowerShell)
```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
Copy-Item .env.example .env
```
Fill `.env` from the EXACT approved DEV Insomnia/Azure configurations.

## Safest first run
```powershell
python main.py --case 00164857 --member 3994391301 --skip-doc --skip-gpt
```
Inspect `output/00164857/raw/*.json`. Update `APPLICATION_ID_PATH` and `PERSON_ID_PATH` if Application Details nests those fields.

## With local DEV PDF + Document Intelligence
```powershell
python main.py --case 00164857 --member 3994391301 --pdf "C:\path\dev.pdf" --skip-gpt
```

## Full run
First verify `gpt_client.py` payload against the approved internal GPT inference contract, then:
```powershell
python main.py --case 00164857 --member 3994391301
```

Notes:
- Salesforce Member Number is NOT assumed to equal applicationId/personId.
- Only read APIs are included.
- Tokens/secrets are never printed.
- Rotate credentials exposed in screenshots and never commit `.env`.
