from pathlib import Path
from azure.identity import ClientSecretCredential
from azure.ai.documentintelligence import DocumentIntelligenceClient
import config
def ready(): return all([config.AZ_TENANT,config.AZ_CLIENT,config.AZ_SECRET,config.DI_ENDPOINT])
def extract(path):
    cred=ClientSecretCredential(config.AZ_TENANT,config.AZ_CLIENT,config.AZ_SECRET)
    cli=DocumentIntelligenceClient(config.DI_ENDPOINT,cred)
    with Path(path).open("rb") as f:
        result=cli.begin_analyze_document("prebuilt-read",body=f).result()
    return result.content or ""
