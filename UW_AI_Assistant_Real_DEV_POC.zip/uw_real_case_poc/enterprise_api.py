import requests, config
class EnterpriseAPI:
    def __init__(self): self.s=requests.Session(); self.token=None
    def auth(self):
        if self.token: return self.token
        p={"grant_type":"client_credentials","client_id":config.CID,"client_secret":config.SECRET}
        if config.SCOPE: p["scope"]=config.SCOPE
        r=self.s.post(config.TOKEN_URL,data=p,timeout=30); r.raise_for_status()
        self.token=r.json()["access_token"]; return self.token
    def get(self,url,params=None):
        r=self.s.get(url,params=params,headers={"Authorization":f"Bearer {self.auth()}","Accept":"application/json"},timeout=60)
        r.raise_for_status(); return r.json()
    def bytes(self,url,params=None):
        r=self.s.get(url,params=params,headers={"Authorization":f"Bearer {self.auth()}"},timeout=90)
        r.raise_for_status(); return r.content,r.headers.get("content-type","")
