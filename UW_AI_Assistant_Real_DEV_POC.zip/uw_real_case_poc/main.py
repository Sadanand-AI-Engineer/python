import argparse,json
from pathlib import Path
import config
from enterprise_api import EnterpriseAPI
from document_reader import ready as di_ready, extract
from gpt_client import GPT

def dg(o,p):
    for x in p.split("."):
        if not isinstance(o,dict) or x not in o:return None
        o=o[x]
    return o
def save(p,o): p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(o,indent=2,default=str),encoding="utf-8")
def call(name,fn,out):
    try:
        x=fn();save(out/f"{name}.json",x);print("[PASS]",name);return x
    except Exception as e: print("[SKIP/FAIL]",name,type(e).__name__,e);return None
def first_doc(x):
    a=x if isinstance(x,list) else next((x.get(k) for k in ("documents","items","results","value") if isinstance(x,dict) and isinstance(x.get(k),list)),[])
    if a and isinstance(a[0],dict):
        return next((str(a[0][k]) for k in ("documentId","document_id","id") if a[0].get(k)),None)

def main():
    ap=argparse.ArgumentParser();ap.add_argument("--case",required=True);ap.add_argument("--member",required=True);ap.add_argument("--pdf");ap.add_argument("--skip-doc",action="store_true");ap.add_argument("--skip-gpt",action="store_true");a=ap.parse_args()
    out=Path("output")/a.case;raw=out/"raw";out.mkdir(parents=True,exist_ok=True)
    print("UW AI ASSISTANT - READ-ONLY DEV POC",a.case,a.member,sep="\n")
    api=EnterpriseAPI(); data={"case_number":a.case,"member_number":a.member}
    app=call("application_details",lambda:api.get(config.URLS["application_details"],{config.PARAMS["application_details"]:a.member}),raw) if config.URLS["application_details"] else None
    data["application_details"]=app; aid=dg(app,config.APP_PATH) if app else None; pid=dg(app,config.PERSON_PATH) if app else None
    print("[INFO] applicationId:", "found" if aid else "not found");print("[INFO] personId:","found" if pid else "not found")
    for n,ident in [("application_questions",aid),("irix",aid),("contact_history",pid),("person_activities",pid)]:
        data[n]=call(n,lambda n=n,i=ident:api.get(config.URLS[n],{config.PARAMS[n]:i}),raw) if config.URLS[n] and ident else None
    docs=call("search_documents",lambda:api.get(config.URLS["search_documents"],{config.PARAMS["search_documents"]:a.member}),raw) if config.URLS["search_documents"] else None
    data["search_documents"]=docs;save(out/"case_context_raw.json",data)
    text=""; pdf=Path(a.pdf) if a.pdf else None
    if not a.skip_doc and not pdf and docs and config.URLS["get_document"]:
        did=first_doc(docs)
        if did:
            try:
                b,ct=api.bytes(config.URLS["get_document"],{config.PARAMS["get_document"]:did}); pdf=out/"member_document.pdf";pdf.write_bytes(b);print("[PASS] document download")
            except Exception as e: print("[SKIP/FAIL] document download",e)
    if not a.skip_doc and pdf and pdf.exists() and di_ready():
        try:text=extract(pdf);(out/"document_text.txt").write_text(text,encoding="utf-8");print("[PASS] Document Intelligence")
        except Exception as e:print("[SKIP/FAIL] Document Intelligence",e)
    prompt="Summarize this DEV underwriting case using ONLY supplied evidence. Do not make an underwriting decision. Name the source for major findings and identify missing information.\n\nSTRUCTURED:\n"+json.dumps(data,indent=2,default=str)+"\n\nDOCUMENT:\n"+(text[:30000] or "(unavailable)")
    (out/"prompt_preview.txt").write_text(prompt,encoding="utf-8")
    if not a.skip_gpt and all([config.GPT_TOKEN,config.GPT_CID,config.GPT_SECRET,config.GPT_ENDPOINT]):
        try:s=GPT().summarize(prompt);(out/"summary.txt").write_text(s,encoding="utf-8");print("[PASS] GPT inference\n\n",s)
        except Exception as e:print("[SKIP/FAIL] GPT inference",e)
    print("\nArtifacts:",out.resolve())
if __name__=="__main__":main()
