import os
from dotenv import load_dotenv
load_dotenv()
def e(n,d=""): return os.getenv(n,d).strip()
TOKEN_URL=e("ENTERPRISE_TOKEN_URL"); CID=e("ENTERPRISE_CLIENT_ID"); SECRET=e("ENTERPRISE_CLIENT_SECRET"); SCOPE=e("ENTERPRISE_SCOPE")
URLS={k:e(v) for k,v in {"application_details":"APPLICATION_DETAILS_URL","application_questions":"APPLICATION_QUESTIONS_URL","irix":"IRIX_URL","contact_history":"CONTACT_HISTORY_URL","person_activities":"PERSON_ACTIVITIES_URL","search_documents":"SEARCH_DOCUMENTS_URL","get_document":"GET_DOCUMENT_URL"}.items()}
PARAMS={k:e(v,d) for k,v,d in [("application_details","APPLICATION_DETAILS_ID_PARAM","memberNumber"),("application_questions","APPLICATION_QUESTIONS_ID_PARAM","applicationId"),("irix","IRIX_ID_PARAM","applicationId"),("contact_history","CONTACT_HISTORY_ID_PARAM","person_id"),("person_activities","PERSON_ACTIVITIES_ID_PARAM","person_id"),("search_documents","SEARCH_DOCUMENTS_ID_PARAM","memberNumber"),("get_document","GET_DOCUMENT_ID_PARAM","documentId")]}
APP_PATH=e("APPLICATION_ID_PATH","applicationId"); PERSON_PATH=e("PERSON_ID_PATH","personId")
AZ_TENANT=e("AZURE_TENANT_ID"); AZ_CLIENT=e("AZURE_CLIENT_ID"); AZ_SECRET=e("AZURE_CLIENT_SECRET"); DI_ENDPOINT=e("DOCUMENT_INTELLIGENCE_ENDPOINT")
GPT_TOKEN=e("GPT_TOKEN_URL"); GPT_CID=e("GPT_CLIENT_ID"); GPT_SECRET=e("GPT_CLIENT_SECRET"); GPT_SCOPE=e("GPT_SCOPE"); GPT_ENDPOINT=e("GPT_ENDPOINT"); GPT_MODEL=e("GPT_MODEL","gpt-5"); GPT_PROJECT=e("GPT_PROJECT_ID")
