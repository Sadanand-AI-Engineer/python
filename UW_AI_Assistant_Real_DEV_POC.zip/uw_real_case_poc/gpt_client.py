import requests, config
class GPT:
    def token(self):
        p={"grant_type":"client_credentials","client_id":config.GPT_CID,"client_secret":config.GPT_SECRET}
        if config.GPT_SCOPE: p["scope"]=config.GPT_SCOPE
        r=requests.post(config.GPT_TOKEN,data=p,timeout=30); r.raise_for_status(); return r.json()["access_token"]
    def summarize(self,prompt):
        # IMPORTANT: verify this payload against your approved internal GPT gateway contract.
        payload={"model":config.GPT_MODEL,"messages":[{"role":"system","content":"Use only supplied evidence. Do not make an underwriting decision. Do not invent facts. Name supporting sources and missing information."},{"role":"user","content":prompt}],"temperature":0}
        if config.GPT_PROJECT: payload["project_id"]=config.GPT_PROJECT
        r=requests.post(config.GPT_ENDPOINT,json=payload,headers={"Authorization":f"Bearer {self.token()}","Content-Type":"application/json"},timeout=120)
        r.raise_for_status(); b=r.json()
        try: return b["choices"][0]["message"]["content"]
        except Exception: raise RuntimeError("GPT response schema differs from common chat format; update gpt_client.py using approved gateway contract.")
